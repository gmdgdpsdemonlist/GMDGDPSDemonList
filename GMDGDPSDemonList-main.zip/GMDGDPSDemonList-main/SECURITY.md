# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.0.3   | :white_check_mark: |

## Reporting a Vulnerability

You can Report vulnerabilities through the
[discord server](https://discord.gg/cVbNtT8Rtc) or by DM'ing normalperson
(normalperson4198). Responses to vulnerability reports usually take
around 3 hours to more than a day, depending on how difficult fixing a
vulnerability is.
